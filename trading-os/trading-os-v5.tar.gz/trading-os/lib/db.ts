import { createClient } from "@libsql/client";
import path from "path";

const DB_PATH = path.join(process.cwd(), "trading.db");
export const db = createClient({ url: `file:${DB_PATH}` });

export async function initDB() {
  await db.executeMultiple(`
    CREATE TABLE IF NOT EXISTS trades (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      date TEXT NOT NULL,
      pair TEXT NOT NULL,
      direction TEXT NOT NULL,
      setup TEXT NOT NULL,
      session TEXT DEFAULT 'London',
      entry REAL NOT NULL,
      exit_price REAL,
      stop_loss REAL DEFAULT 0,
      take_profit REAL,
      risk_percent REAL DEFAULT 1,
      pnl REAL DEFAULT 0,
      rr_planned REAL,
      rr_real REAL,
      outcome TEXT DEFAULT 'WIN',
      elliott_wave TEXT DEFAULT '',
      wyckoff_phase TEXT DEFAULT '',
      wyckoff_event TEXT DEFAULT '',
      imbalance_zone TEXT DEFAULT '',
      htf_bias TEXT DEFAULT '',
      confluences TEXT DEFAULT '',
      entry_reason TEXT DEFAULT '',
      shock_type TEXT DEFAULT '',
      shock_timeframe TEXT DEFAULT '',
      management TEXT DEFAULT '',
      lesson TEXT DEFAULT '',
      notes TEXT DEFAULT '',
      screenshot_before TEXT DEFAULT '',
      screenshot_after TEXT DEFAULT '',
      screenshot_entry TEXT DEFAULT '',
      tags TEXT DEFAULT '',
      mental_state TEXT DEFAULT 'B',
      followed_plan INTEGER DEFAULT 1,
      sleep_quality INTEGER DEFAULT 5,
      fatigue_level INTEGER DEFAULT 5,
      stress_level INTEGER DEFAULT 5,
      anxiety_level INTEGER DEFAULT 5,
      focus_level INTEGER DEFAULT 5,
      confidence_level INTEGER DEFAULT 5,
      emotional_state TEXT DEFAULT '',
      pre_session_notes TEXT DEFAULT '',
      post_trade_emotion TEXT DEFAULT '',
      created_at TEXT DEFAULT (datetime('now'))
    );

    CREATE TABLE IF NOT EXISTS setups (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      name TEXT NOT NULL UNIQUE,
      category TEXT DEFAULT 'Custom',
      description TEXT DEFAULT '',
      steps TEXT DEFAULT '',
      timeframes TEXT DEFAULT '',
      markets TEXT DEFAULT '',
      confluence TEXT DEFAULT '',
      invalidation TEXT DEFAULT '',
      image_refs TEXT DEFAULT '[]',
      active INTEGER DEFAULT 1,
      created_at TEXT DEFAULT (datetime('now'))
    );

    CREATE TABLE IF NOT EXISTS principles (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      title TEXT NOT NULL,
      body TEXT NOT NULL,
      category TEXT DEFAULT 'general',
      created_at TEXT DEFAULT (datetime('now'))
    );

    CREATE TABLE IF NOT EXISTS mental_logs (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      date TEXT NOT NULL,
      sleep_hours REAL DEFAULT 7,
      sleep_quality INTEGER DEFAULT 5,
      fatigue_level INTEGER DEFAULT 5,
      stress_level INTEGER DEFAULT 5,
      anxiety_level INTEGER DEFAULT 5,
      focus_level INTEGER DEFAULT 5,
      confidence_level INTEGER DEFAULT 5,
      mood_score INTEGER DEFAULT 5,
      physical_state TEXT DEFAULT '',
      before_session TEXT DEFAULT '',
      after_session TEXT DEFAULT '',
      notes TEXT DEFAULT '',
      created_at TEXT DEFAULT (datetime('now'))
    );

    CREATE TABLE IF NOT EXISTS weekly_journals (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      week_start TEXT NOT NULL UNIQUE,
      week_end TEXT NOT NULL,
      overall_grade TEXT DEFAULT 'B',
      pnl_total REAL DEFAULT 0,
      trades_count INTEGER DEFAULT 0,
      wins INTEGER DEFAULT 0,
      losses INTEGER DEFAULT 0,
      violations INTEGER DEFAULT 0,
      best_trade TEXT DEFAULT '',
      worst_trade TEXT DEFAULT '',
      technical_review TEXT DEFAULT '',
      psychological_review TEXT DEFAULT '',
      rule_compliance TEXT DEFAULT '',
      setups_analysis TEXT DEFAULT '',
      goals_met TEXT DEFAULT '',
      goals_next_week TEXT DEFAULT '',
      mindset_notes TEXT DEFAULT '',
      lessons TEXT DEFAULT '',
      avg_sleep REAL DEFAULT 0,
      avg_stress REAL DEFAULT 0,
      avg_focus REAL DEFAULT 0,
      created_at TEXT DEFAULT (datetime('now'))
    );

    CREATE TABLE IF NOT EXISTS ai_analyses (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      period TEXT NOT NULL,
      analysis TEXT NOT NULL,
      created_at TEXT DEFAULT (datetime('now'))
    );
  `);

  // Always ensure main setups exist (upsert)
  await seedSetups();

  const cnt2 = await db.execute("SELECT COUNT(*) as c FROM principles");
  if ((cnt2.rows[0] as any).c === 0) {
    await seedPrinciples();
  }
}

async function seedSetups() {
  const setups = [
    {
      name: "W-E Macro Flow",
      category: "Wyckoff+Elliott",
      description: "Leitura macro Wyckoff-first combinada com Elliott Wave. Entry em chock nos imbalances macro. Confluência máxima — todos os timeframes alinhados.",
      steps: JSON.stringify([
        "1. Identificar a onda Elliott na macro (D1/W): determinar se impulso (1-3-5) ou correção (A-B-C, flat, triangle). Marcar onde estamos na contagem.",
        "2. Assinalar estrutura Wyckoff na macro: Acumulação, Distribuição, Re-acumulação ou Re-distribuição. Identificar a fase atual (A/B/C/D/E).",
        "3. Identificar Imbalances/Fair Values na macro (H4/D1): marcar FVGs e zonas de desequilíbrio não preenchidas. Estas são as zonas-alvo de entrada.",
        "4. Timeframes intermédios (H1/H4): identificar estruturas Wyckoff em curso — tipo, fase atual, eventos presentes (Spring/UTAD/SOS/SOW).",
        "5. Aguardar chock (Spring ou UTAD) nos M2/M5 dentro da região de imbalance macro. Confirmar com volume e SOS/SOW bar. SL além do chock."
      ]),
      timeframes: "D1/W (Elliott+Wyckoff macro) | H4/H1 (Wyckoff estrutura) | M15/M5/M2 (entrada)",
      markets: "Forex, Indices, Crypto, Futuros",
      confluence: "Onda Elliott clara + Wyckoff fase D/E + FVG H4 + Spring/UTAD M5 + volume + SOS/SOW bar",
      invalidation: "Onda Elliott ambígua | Wyckoff Fase B | Sem imbalance | Chock sem volume | Contra HTF bias",
      image_refs: JSON.stringify(["wyckoff_reaccumulation","wyckoff_redistribution","elliott_corrections","elliott_complex","elliott_triangles"])
    },
    {
      name: "E-W Impulse Rider",
      category: "Elliott+Wyckoff",
      description: "Leitura macro Elliott-first. Identifica a onda, valida com Wyckoff macro, procura padrões corretivos intermédios e entra no chock dentro do imbalance macro.",
      steps: JSON.stringify([
        "1. Identificar a onda Elliott na macro (D1/W): contar ondas, determinar posição. Marcar níveis de Fibonacci da onda em curso.",
        "2. Assinalar estrutura Wyckoff na macro (D1/H4): validar contexto direcional da onda Elliott identificada.",
        "3. Identificar Imbalances/Fair Values na macro (H4/D1): marcar FVGs que coincidem com retrocessos de Fibonacci.",
        "4. Timeframes intermédios (H1/H4): identificar padrão Elliott — flat irregular, retração regular, triângulo, ABCD, ABC. Medir extensões Fibonacci para TP.",
        "5. Aguardar chock (Spring/UTAD) nos M2/M5 dentro da região de imbalance + Fibonacci. Confirmar com SOS/SOW bar. SL além do chock."
      ]),
      timeframes: "D1/W (Elliott + Wyckoff) | H4/H1 (padrão corretivo Elliott) | M5/M2 (entrada chock)",
      markets: "Forex, Indices, Crypto, Futuros",
      confluence: "Elliott clara + padrão corretivo completo + FVG na zona Fibonacci + Chock M5 + SOS/SOW bar",
      invalidation: "Contagem Elliott ambígua | Padrão corretivo incompleto | Sem FVG | Chock sem confirmação",
      image_refs: JSON.stringify(["elliott_corrections","elliott_complex","elliott_triangles","wyckoff_reaccumulation","wyckoff_redistribution"])
    },
    {
      name: "ICT MSS + OB",
      category: "ICT",
      description: "Market Structure Shift seguido de reentrada no Order Block.",
      steps: JSON.stringify([
        "1. Identificar trend dominante no H4/D1 — determinar bias geral",
        "2. Aguardar MSS (Market Structure Shift / BOS) no H1",
        "3. Identificar o Order Block que causou o MSS",
        "4. Aguardar retorno ao OB com diminuição de volume",
        "5. Confirmar rejeição no M15/M5 com vela de inversão",
        "6. SL abaixo/acima do OB | TP no próximo nível de liquidez"
      ]),
      timeframes: "D1/H4 (bias) | H1 (MSS) | M15/M5 (entrada)",
      markets: "Forex, Indices",
      confluence: "BOS H4 + OB H1 + FVG M15 + Volume decrescente no retorno",
      invalidation: "Vela fecha dentro do OB | OB violado sem recuperação",
      image_refs: "[]"
    },
    {
      name: "FVG + OB",
      category: "ICT",
      description: "Fair Value Gap combinado com Order Block.",
      steps: JSON.stringify([
        "1. Identificar FVG no H1 após movimento impulsivo",
        "2. Verificar OB na zona do FVG (confluência)",
        "3. Aguardar retorno à zona",
        "4. Confirmar rejeição no M15",
        "5. Entrar na sobreposição FVG+OB com SL além da zona"
      ]),
      timeframes: "H4/H1 (FVG+OB) | M15 (confirmação)",
      markets: "Forex, Indices, Crypto",
      confluence: "FVG + OB alinhados + EQH/EQL como target",
      invalidation: "Preço fecha através do FVG | OB sem rejeição",
      image_refs: "[]"
    },
    {
      name: "Liquidity Sweep",
      category: "ICT",
      description: "Sweep de liquidez (BSL/SSL) seguido de reversão.",
      steps: JSON.stringify([
        "1. Identificar pool de liquidez clara (EQH/EQL, highs/lows anteriores)",
        "2. Aguardar sweep com wick pronunciado",
        "3. Confirmar CISD no M15",
        "4. Entrada após close de confirmação",
        "5. SL acima/abaixo do wick | TP no nível oposto"
      ]),
      timeframes: "H4/H1 | M15/M5",
      markets: "Forex",
      confluence: "Sweep limpo + CISD M15 + FVG na direção",
      invalidation: "Preço continua na direção do sweep",
      image_refs: "[]"
    }
  ];

  for (const s of setups) {
    await db.execute({
      sql: `INSERT OR IGNORE INTO setups (name,category,description,steps,timeframes,markets,confluence,invalidation,image_refs) VALUES (?,?,?,?,?,?,?,?,?)`,
      args: [s.name,s.category,s.description,s.steps,s.timeframes,s.markets,s.confluence,s.invalidation,s.image_refs],
    });
  }
}

async function seedPrinciples() {
  const principles = [
    ["Só trades com setup catalogado","Nunca entrar sem um dos setups definidos.","discipline"],
    ["Pausa após 2 losses consecutivos","30 minutos de pausa obrigatória após 2 perdas.","risk"],
    ["Risk máximo 1% por trade","Nunca arriscar mais de 1%. Score mental <5: máximo 0.5%.","risk"],
    ["Sem trading com sono <6h ou stress >7","Condições de não-trading.","psychology"],
    ["Estado mental D = sem trading","Fechar plataforma, sem exceções.","psychology"],
    ["Chock obrigatório para entrar","Sem Spring/UTAD nos M5/M2: sem entrada.","strategy"],
    ["Elliott + Wyckoff devem alinhar","Os dois sistemas na mesma direção na macro.","strategy"],
    ["Máximo 3 trades por dia","Após 3 trades, encerrar sessão.","discipline"],
    ["Sem trading antes de High Impact News","Fechar posições 30min antes de NFP, CPI, FOMC.","risk"],
    ["Journal obrigatório em cada trade","Registo técnico + mental completo.","discipline"],
    ["Revisão semanal todo domingo","Journal semanal, ajustar metas.","discipline"],
  ];
  for (const p of principles) {
    await db.execute({ sql:`INSERT INTO principles (title,body,category) VALUES (?,?,?)`, args:p });
  }
}
